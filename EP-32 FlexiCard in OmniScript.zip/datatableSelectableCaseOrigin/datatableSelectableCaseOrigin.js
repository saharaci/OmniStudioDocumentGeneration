import { LightningElement, api, track } from 'lwc';
import { OmniscriptBaseMixin } from 'omnistudio/omniscriptBaseMixin';

export default class DatatableSelectableDiscipline extends OmniscriptBaseMixin(LightningElement) {
    @api records;   
    @api columns;    
    data =[];
    selectedCaseOriginRows=[];    

    connectedCallback(){
        this.data = this.records;        
        this.columns=this.columns;       
        console.log('columns = '+JSON.stringify(this.columns));
        console.log("Records = " + JSON.stringify(this.records));
        this.template.addEventListener('selectrow', event => {
            console.log('selectedrow event' + JSON.stringify(event.detail.result));
            if (event.detail.result === "all") {
                this.selectedCaseOriginRows = this.records;
            } else if (event.detail.result === "none") {
                this.selectedCaseOriginRows = [];
            } else if(event.detail.result.selectrow) {
                this.selectedCaseOriginRows.push(event.detail.result);
            } else {
                this.selectedCaseOriginRows.forEach(function(item, index, object) {
                    if(item.uniqueKey === event.detail.result.uniqueKey) {
                        object.splice(index, 1);
                    }
                })
            }
            this.omniApplyCallResp({"selectedCaseOriginRows": this.selectedCaseOriginRows});
        });
    }
}